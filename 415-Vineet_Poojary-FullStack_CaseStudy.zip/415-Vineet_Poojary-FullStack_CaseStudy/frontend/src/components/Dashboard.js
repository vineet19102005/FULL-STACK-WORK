import React, { useState, useEffect } from 'react';
import axios from 'axios';
import box from './box.png';

const Dashboard = () => {
  const [products, setProducts] = useState([]);
  const [minprice, setMinPrice] = useState(0);
  const [maxprice, setMaxPrice] = useState(5000);
  const [categories, setCategories] = useState("");  
  const [brands, setBrands] = useState("");  
  const [allCategories, setAllCategories] = useState([]);
  const [allBrands, setAllBrands] = useState([]);

  const fetchProducts = async () => {
    try {
      const response = await axios.get('http://localhost:3000/listProducts', {
        params: { 
          brand: brands, 
          category: categories,  
          minprice,
          maxprice
        }
      });
      setProducts(response.data.products);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  useEffect(() => {
    axios.get('http://localhost:3000/filters')
      .then(response => {
        setAllCategories(response.data.categories || []);  
        setAllBrands(response.data.brands || []);  
      })
      .catch(error => {
        console.error('Error fetching filters:', error);
      });
  
    fetchProducts();
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [minprice, maxprice, categories, brands]);

  const styles = {
    container: {
      textAlign: 'center',
      padding: '20px',
    },
    filtersContainer: {
      display: 'flex',
      justifyContent: 'space-between',
      padding: '20px',
    },
    filter: {
      margin: '10px',
    },
    productCard: {
      border: '1px solid #ccc',
      borderRadius: '8px',
      padding: '16px',
      margin: '10px',
      width: '275px',
    },
    productsGrid: {
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'center',
    },
  };

  return (
    <div style={styles.container}>
      <h1>Product Dashboard</h1>

      <div style={styles.filtersContainer}>
        {/* Price Range Filter */}
        <div style={styles.filter}>
          <label>Price Range: {minprice} - {maxprice}</label>
          <input
            type="range"
            min="0"
            max="5000"
            value={minprice}
            onChange={e => setMinPrice(e.target.value)}
          />
          <input
            type="range"
            min="0"
            max="5000"
            value={maxprice}
            onChange={e => setMaxPrice(e.target.value)}
          />
        </div>

        {/* Category Filter */}
        <div style={styles.filter}>
          <label>Category</label>
          <select value={categories} onChange={e => setCategories(e.target.value)}>
            <option value="">All Categories</option>
            {allCategories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>

        {/* Brand Filter */}
        <div style={styles.filter}>
          <label>Brand</label>
          <select value={brands} onChange={e => setBrands(e.target.value)}>
            <option value="">All Brands</option>
            {allBrands.map(b => (
              <option key={b} value={b}>{b}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Product Cards */}
      <div style={styles.productsGrid}>
        {products.map(product => (
          <div key={product.id} style={styles.productCard}>
            <img src={box} alt={product.name} />
            <h3>{product.name}</h3>
            <p>{product.description}</p>
            <p>Price: ₹{product.price}</p>
            <p>Brand: {product.brand}</p>
            <p>Category: {product.category}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
